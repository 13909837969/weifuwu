/*
Navicat MySQL Data Transfer

Source Server         : MYSQL
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : yorbest_gw

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2017-12-29 11:28:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ico
-- ----------------------------
DROP TABLE IF EXISTS `ico`;
CREATE TABLE `ico` (
  `icoId` int(11) NOT NULL AUTO_INCREMENT,
  `icoName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`icoId`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ico
-- ----------------------------
INSERT INTO `ico` VALUES ('1', 'fa-arrows');
INSERT INTO `ico` VALUES ('2', ' fa-bookmark-o');
INSERT INTO `ico` VALUES ('3', 'fa-bug');
INSERT INTO `ico` VALUES ('4', 'fa-comments-o');
INSERT INTO `ico` VALUES ('5', 'fa-desktop');
INSERT INTO `ico` VALUES ('6', 'fa-sitemap');
INSERT INTO `ico` VALUES ('7', 'fa-tachometer');
INSERT INTO `ico` VALUES ('8', 'fa-tags');
INSERT INTO `ico` VALUES ('9', 'fa-windows');
INSERT INTO `ico` VALUES ('10', 'fa-hospital-o');
INSERT INTO `ico` VALUES ('11', 'fa-youtube-play');
INSERT INTO `ico` VALUES ('12', 'fa-tint');
INSERT INTO `ico` VALUES ('13', 'fa-star-o');
INSERT INTO `ico` VALUES ('14', 'fa-shield');
INSERT INTO `ico` VALUES ('15', 'fa-power-off');
INSERT INTO `ico` VALUES ('16', 'fa-map-marker');
INSERT INTO `ico` VALUES ('17', 'fa-leaf');
INSERT INTO `ico` VALUES ('18', 'fa-laptop');
INSERT INTO `ico` VALUES ('19', 'fa-home');
INSERT INTO `ico` VALUES ('20', 'fa-globe');
INSERT INTO `ico` VALUES ('21', 'fa-cloud');
INSERT INTO `ico` VALUES ('22', 'fa-anchor');
INSERT INTO `ico` VALUES ('23', ' fa-sun-o');
INSERT INTO `ico` VALUES ('24', 'fa-rocket');
INSERT INTO `ico` VALUES ('25', 'fa-mobile');
INSERT INTO `ico` VALUES ('26', ' fa-bars');
INSERT INTO `ico` VALUES ('27', ' fa-heart-o');
INSERT INTO `ico` VALUES ('28', 'fa-flask');
INSERT INTO `ico` VALUES ('29', 'fa-gamepad');
INSERT INTO `ico` VALUES ('30', 'fa-info');
INSERT INTO `ico` VALUES ('31', ' fa-pagelines');
INSERT INTO `ico` VALUES ('32', 'fa-twitter');

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `menuId` int(11) NOT NULL AUTO_INCREMENT,
  `menuName` varchar(255) DEFAULT NULL,
  `menuFather` int(11) DEFAULT NULL,
  `menuUrl` varchar(255) DEFAULT NULL,
  `menuPic` varchar(255) DEFAULT NULL,
  `menuOrder` int(11) DEFAULT NULL,
  `fatherId` int(11) DEFAULT NULL,
  `idx` int(11) DEFAULT NULL,
  PRIMARY KEY (`menuId`),
  KEY `FK33155F72BF0516` (`fatherId`),
  CONSTRAINT `FK33155F72BF0516` FOREIGN KEY (`fatherId`) REFERENCES `menu` (`menuId`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('1', '/', '-1', null, null, null, null, null);
INSERT INTO `menu` VALUES ('11', '系统设置', '1', '', 'fa-star-o', '2', null, null);
INSERT INTO `menu` VALUES ('12', '用户管理', '11', 'UserServlet?user=list', '', '1', '11', '0');
INSERT INTO `menu` VALUES ('13', '菜单管理', '11', 'MenuServlet?menu=list', '', '2', '11', '1');
INSERT INTO `menu` VALUES ('14', '角色管理', '11', 'RoleServlet?role=list', '', '3', '11', '2');
INSERT INTO `menu` VALUES ('15', '首页', '1', 'manager/admin_Index_Main.jsp', 'fa-tachometer', '1', null, null);
INSERT INTO `menu` VALUES ('17', '系统公告', '11', 'NoticeServlet?notice=users', '', '32', '11', '3');
INSERT INTO `menu` VALUES ('18', '账户消息', '11', 'NoticeServlet?notice=list', '', '123', '11', '4');
INSERT INTO `menu` VALUES ('19', '常见问题', '1', 'manager/faq.html', 'fa-anchor', '2', null, null);

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `noticeId` int(11) NOT NULL AUTO_INCREMENT,
  `noticeTitle` varchar(255) DEFAULT NULL,
  `noticeDate` varchar(255) DEFAULT NULL,
  `noticeContent` longtext,
  PRIMARY KEY (`noticeId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('17', 'You Are Not Alone', '10/18/2017', '<p style=\"text-align: center;\">In my heart.....For I am here with you</p>\r\n\r\n<p style=\"text-align: center;\">在我心里 我和你在一起</p>\r\n\r\n<p style=\"text-align: center;\">Heart.....Though we&#39;re far apart</p>\r\n\r\n<p style=\"text-align: center;\">心里。尽快我们分开</p>\r\n\r\n<p style=\"text-align: center;\">Heart.....You&#39;re always in my heart</p>\r\n\r\n<p style=\"text-align: center;\">心里。你一直在我心里</p>\r\n\r\n<p style=\"text-align: center;\">For you are not alone</p>\r\n\r\n<p style=\"text-align: center;\">你不会孤单</p>\r\n\r\n<p style=\"text-align: center;\">Not alone</p>\r\n\r\n<p style=\"text-align: center;\">并不孤单</p>\r\n');
INSERT INTO `notice` VALUES ('18', '大苏打', '10/19/2017', '<p>阿斯达斯</p>\r\n');
INSERT INTO `notice` VALUES ('20', '越难越爱', '12/10/2017', '<p>软弱会再有气概 跟处境比赛</p>\r\n\r\n<p>在途上就算有些感慨</p>\r\n\r\n<p>让我 学会抱紧撑到未来</p>\r\n\r\n<p>别让手放开</p>\r\n');

-- ----------------------------
-- Table structure for notice_users
-- ----------------------------
DROP TABLE IF EXISTS `notice_users`;
CREATE TABLE `notice_users` (
  `noticeId` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `idr` int(11) NOT NULL,
  PRIMARY KEY (`noticeId`,`idr`),
  KEY `FK128405E15A41190B` (`noticeId`),
  CONSTRAINT `FK128405E15A41190B` FOREIGN KEY (`noticeId`) REFERENCES `notice` (`noticeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice_users
-- ----------------------------
INSERT INTO `notice_users` VALUES ('17', '9', '0');
INSERT INTO `notice_users` VALUES ('18', '9', '0');
INSERT INTO `notice_users` VALUES ('20', '4', '0');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(255) DEFAULT NULL,
  `roleDesc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', '超级管理员', '不需要修改');
INSERT INTO `role` VALUES ('2', '游客', '只能查看首页');
INSERT INTO `role` VALUES ('6', '官网', '首页和账户消息');

-- ----------------------------
-- Table structure for role_menus
-- ----------------------------
DROP TABLE IF EXISTS `role_menus`;
CREATE TABLE `role_menus` (
  `roleId` int(11) NOT NULL,
  `menuid` int(11) DEFAULT NULL,
  `idm` int(11) NOT NULL,
  PRIMARY KEY (`roleId`,`idm`),
  KEY `FK6C80C9EBC90CC7` (`roleId`),
  CONSTRAINT `FK6C80C9EBC90CC7` FOREIGN KEY (`roleId`) REFERENCES `role` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role_menus
-- ----------------------------
INSERT INTO `role_menus` VALUES ('2', '15', '0');
INSERT INTO `role_menus` VALUES ('6', '18', '0');
INSERT INTO `role_menus` VALUES ('6', '15', '1');

-- ----------------------------
-- Table structure for role_users
-- ----------------------------
DROP TABLE IF EXISTS `role_users`;
CREATE TABLE `role_users` (
  `roleId` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `idr` int(11) NOT NULL,
  PRIMARY KEY (`roleId`,`idr`),
  KEY `FK6CF7C0FFC90CC7` (`roleId`),
  CONSTRAINT `FK6CF7C0FFC90CC7` FOREIGN KEY (`roleId`) REFERENCES `role` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role_users
-- ----------------------------
INSERT INTO `role_users` VALUES ('1', '1', '1');
INSERT INTO `role_users` VALUES ('2', '4', '4');
INSERT INTO `role_users` VALUES ('6', '9', '9');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) DEFAULT NULL,
  `userNickName` varchar(255) DEFAULT NULL,
  `userPassWord` varchar(255) DEFAULT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `userPic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '薛增博', '薛增博', '123', '123@qq.com', 'avatar9.jpg');
INSERT INTO `user` VALUES ('4', '徐佳莹', '徐佳莹', '123', '1234@qq.com', 'avatar8.jpg');
INSERT INTO `user` VALUES ('9', '浜崎あゆみ', '浜崎あゆみ', '123', '1232@qq.com', 'avatar5.jpg');

-- ----------------------------
-- Table structure for usernotice
-- ----------------------------
DROP TABLE IF EXISTS `usernotice`;
CREATE TABLE `usernotice` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `noticeState` varchar(255) DEFAULT NULL,
  `noticeTitle` varchar(255) DEFAULT NULL,
  `noticeDate` varchar(255) DEFAULT NULL,
  `noticeContent` longtext,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of usernotice
-- ----------------------------
INSERT INTO `usernotice` VALUES ('17', '1', '0', 'Traveling Light', '10/25/2017', '<p style=\"text-align: center;\">Pathways of trouble</p>\r\n\r\n<p style=\"text-align: center;\">走过这条烦恼不断的旅途！</p>\r\n\r\n<p style=\"text-align: center;\">I was hauling those souvenirs of misery</p>\r\n\r\n<p style=\"text-align: center;\">所有痛苦不幸的回忆让我步履蹒跚</p>\r\n\r\n<p style=\"text-align: center;\">And with each step taken my back was breaking</p>\r\n\r\n<p style=\"text-align: center;\">每一步都仿似将要压弯我的脊梁</p>\r\n\r\n<p style=\"text-align: center;\">&#39;Til I found the One who took it all from me</p>\r\n\r\n<p style=\"text-align: center;\">直到遇到他，我如释重负</p>\r\n\r\n<p style=\"text-align: center;\">Down by the riverside</p>\r\n\r\n<p style=\"text-align: center;\">漫步河畔</p>\r\n\r\n<p style=\"text-align: center;\">（Down by the riverside）</p>\r\n\r\n<p style=\"text-align: center;\">漫步河畔</p>\r\n\r\n<p style=\"text-align: center;\">I laid my burdens down</p>\r\n\r\n<p style=\"text-align: center;\">我卸下满身重负</p>\r\n\r\n<p style=\"text-align: center;\">Now I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">如今我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">My spirit lifted high</p>\r\n\r\n<p style=\"text-align: center;\">满心舒畅一身轻盈</p>\r\n\r\n<p style=\"text-align: center;\">（I found my freedom now）</p>\r\n\r\n<p style=\"text-align: center;\">如今的我终于自由</p>\r\n\r\n<p style=\"text-align: center;\">I found my freedom now</p>\r\n\r\n<p style=\"text-align: center;\">如今的我终于自由</p>\r\n\r\n<p style=\"text-align: center;\">And I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">Through the darkest alleys and loneliest valleys</p>\r\n\r\n<p style=\"text-align: center;\">走过晦暗无光的衢巷，穿越幽暗深邃的幽谷</p>\r\n\r\n<p style=\"text-align: center;\">I was dragging those heavy chains of doubt and fear</p>\r\n\r\n<p style=\"text-align: center;\">所有不安和恐惧化作枷锁让我踉跄难行</p>\r\n\r\n<p style=\"text-align: center;\">Then with the one word spoken the locks were broken</p>\r\n\r\n<p style=\"text-align: center;\">你一句简单的言语便破除了我全部枷锁</p>\r\n\r\n<p style=\"text-align: center;\">Now He&#39;s leading me to places</p>\r\n\r\n<p style=\"text-align: center;\">如今他正引领着我前往</p>\r\n\r\n<p style=\"text-align: center;\">Where there are no tears</p>\r\n\r\n<p style=\"text-align: center;\">那永不伤心落泪的天堂</p>\r\n\r\n<p style=\"text-align: center;\">Down by the riverside</p>\r\n\r\n<p style=\"text-align: center;\">漫步河畔</p>\r\n\r\n<p style=\"text-align: center;\">（Down by the riverside）</p>\r\n\r\n<p style=\"text-align: center;\">漫步河畔</p>\r\n\r\n<p style=\"text-align: center;\">I laid my burdens down</p>\r\n\r\n<p style=\"text-align: center;\">我卸下满身重负</p>\r\n\r\n<p style=\"text-align: center;\">Now I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">如今我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">My spirit lifted high</p>\r\n\r\n<p style=\"text-align: center;\">满心舒畅一身轻盈</p>\r\n\r\n<p style=\"text-align: center;\">（I found my freedom now）</p>\r\n\r\n<p style=\"text-align: center;\">如今的我终于自由</p>\r\n\r\n<p style=\"text-align: center;\">I found my freedom now</p>\r\n\r\n<p style=\"text-align: center;\">如今的我终于自由</p>\r\n\r\n<p style=\"text-align: center;\">And I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">I laid my burdens down</p>\r\n\r\n<p style=\"text-align: center;\">我卸下满身重负</p>\r\n\r\n<p style=\"text-align: center;\">And I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">My spirit lifted high</p>\r\n\r\n<p style=\"text-align: center;\">满心舒畅一身轻盈</p>\r\n\r\n<p style=\"text-align: center;\">I found my freedom now</p>\r\n\r\n<p style=\"text-align: center;\">如今的我终于自由</p>\r\n\r\n<p style=\"text-align: center;\">Now I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">Down by the riverside</p>\r\n\r\n<p style=\"text-align: center;\">漫步河畔</p>\r\n\r\n<p style=\"text-align: center;\">I laid my burdens down</p>\r\n\r\n<p style=\"text-align: center;\">我卸下满身重负</p>\r\n\r\n<p style=\"text-align: center;\">And I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">My spirit lifted high</p>\r\n\r\n<p style=\"text-align: center;\">满心舒畅一身轻盈</p>\r\n\r\n<p style=\"text-align: center;\">I found my freedom now</p>\r\n\r\n<p style=\"text-align: center;\">如今的我终于自由</p>\r\n\r\n<p style=\"text-align: center;\">Now I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">Down by the riverside</p>\r\n\r\n<p style=\"text-align: center;\">漫步河畔</p>\r\n\r\n<p style=\"text-align: center;\">I laid my burdens down,</p>\r\n\r\n<p style=\"text-align: center;\">我卸下满身重负</p>\r\n\r\n<p style=\"text-align: center;\">And I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">My spirit lifted high</p>\r\n\r\n<p style=\"text-align: center;\">满心舒畅一身轻盈</p>\r\n\r\n<p style=\"text-align: center;\">I laid my burdens down</p>\r\n\r\n<p style=\"text-align: center;\">我卸下满身重负</p>\r\n\r\n<p style=\"text-align: center;\">Now I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">如今我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">（I&#39;m traveling light）</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n\r\n<p style=\"text-align: center;\">I found my freedom now</p>\r\n\r\n<p style=\"text-align: center;\">如今的我终于自由</p>\r\n\r\n<p style=\"text-align: center;\">I&#39;m traveling light</p>\r\n\r\n<p style=\"text-align: center;\">我将轻装前行</p>\r\n');
INSERT INTO `usernotice` VALUES ('20', '1', '0', '最远的你是我最近的爱', '10/26/2017', '<p style=\"text-align: center;\">作曲 : 史俊鹏</p>\r\n\r\n<p style=\"text-align: center;\">作词 : 沈陵</p>\r\n\r\n<p style=\"text-align: center;\">夜已沉默心事向谁说</p>\r\n\r\n<p style=\"text-align: center;\">不肯回头所有的爱都错过</p>\r\n\r\n<p style=\"text-align: center;\">别笑我懦弱我始终不能猜透</p>\r\n\r\n<p style=\"text-align: center;\">为何人生淡漠</p>\r\n\r\n<p style=\"text-align: center;\">风雨之后无所谓拥有</p>\r\n\r\n<p style=\"text-align: center;\">萍水相逢你却给我那么多</p>\r\n\r\n<p style=\"text-align: center;\">你挡住寒冬温暖只保留给我</p>\r\n\r\n<p style=\"text-align: center;\">风霜寂寞凋落在你怀中</p>\r\n\r\n<p style=\"text-align: center;\">人生风景在游走</p>\r\n\r\n<p style=\"text-align: center;\">每当孤独我回首</p>\r\n\r\n<p style=\"text-align: center;\">你的爱总在不远地方等着我</p>\r\n\r\n<p style=\"text-align: center;\">岁月如流在穿梭</p>\r\n\r\n<p style=\"text-align: center;\">喜怒哀乐我深锁</p>\r\n\r\n<p style=\"text-align: center;\">只因有你在天涯尽头等着我</p>\r\n\r\n<p style=\"text-align: center;\">风雨之后无所谓拥有</p>\r\n\r\n<p style=\"text-align: center;\">萍水相逢你却给我那么多</p>\r\n\r\n<p style=\"text-align: center;\">你挡住寒冬温暖只保留给我</p>\r\n\r\n<p style=\"text-align: center;\">风霜寂寞凋落在你怀中</p>\r\n\r\n<p style=\"text-align: center;\">人生风景在游走</p>\r\n\r\n<p style=\"text-align: center;\">每当孤独我回首</p>\r\n\r\n<p style=\"text-align: center;\">你的爱总在不远地方等着我</p>\r\n\r\n<p style=\"text-align: center;\">岁月如流在穿梭</p>\r\n\r\n<p style=\"text-align: center;\">喜怒哀乐我深锁</p>\r\n\r\n<p style=\"text-align: center;\">只因有你在天涯尽头等着我</p>\r\n\r\n<p style=\"text-align: center;\">人生风景在游走</p>\r\n\r\n<p style=\"text-align: center;\">每当孤独我回首</p>\r\n\r\n<p style=\"text-align: center;\">你的爱总在不远地方等着我</p>\r\n\r\n<p style=\"text-align: center;\">岁月如流在穿梭</p>\r\n\r\n<p style=\"text-align: center;\">喜怒哀乐我深锁</p>\r\n\r\n<p style=\"text-align: center;\">只因有你在天涯尽头等着我</p>\r\n\r\n<p style=\"text-align: center;\">人生风景在游走</p>\r\n\r\n<p style=\"text-align: center;\">每当孤独我回首</p>\r\n\r\n<p style=\"text-align: center;\">你的爱总在不远地方等着我</p>\r\n');
INSERT INTO `usernotice` VALUES ('21', '4', '1', '最远的你是我最近的爱', '10/26/2017', '<p style=\"text-align: center;\">作曲 : 史俊鹏</p>\r\n\r\n<p style=\"text-align: center;\">作词 : 沈陵</p>\r\n\r\n<p style=\"text-align: center;\">夜已沉默心事向谁说</p>\r\n\r\n<p style=\"text-align: center;\">不肯回头所有的爱都错过</p>\r\n\r\n<p style=\"text-align: center;\">别笑我懦弱我始终不能猜透</p>\r\n\r\n<p style=\"text-align: center;\">为何人生淡漠</p>\r\n\r\n<p style=\"text-align: center;\">风雨之后无所谓拥有</p>\r\n\r\n<p style=\"text-align: center;\">萍水相逢你却给我那么多</p>\r\n\r\n<p style=\"text-align: center;\">你挡住寒冬温暖只保留给我</p>\r\n\r\n<p style=\"text-align: center;\">风霜寂寞凋落在你怀中</p>\r\n\r\n<p style=\"text-align: center;\">人生风景在游走</p>\r\n\r\n<p style=\"text-align: center;\">每当孤独我回首</p>\r\n\r\n<p style=\"text-align: center;\">你的爱总在不远地方等着我</p>\r\n\r\n<p style=\"text-align: center;\">岁月如流在穿梭</p>\r\n\r\n<p style=\"text-align: center;\">喜怒哀乐我深锁</p>\r\n\r\n<p style=\"text-align: center;\">只因有你在天涯尽头等着我</p>\r\n\r\n<p style=\"text-align: center;\">风雨之后无所谓拥有</p>\r\n\r\n<p style=\"text-align: center;\">萍水相逢你却给我那么多</p>\r\n\r\n<p style=\"text-align: center;\">你挡住寒冬温暖只保留给我</p>\r\n\r\n<p style=\"text-align: center;\">风霜寂寞凋落在你怀中</p>\r\n\r\n<p style=\"text-align: center;\">人生风景在游走</p>\r\n\r\n<p style=\"text-align: center;\">每当孤独我回首</p>\r\n\r\n<p style=\"text-align: center;\">你的爱总在不远地方等着我</p>\r\n\r\n<p style=\"text-align: center;\">岁月如流在穿梭</p>\r\n\r\n<p style=\"text-align: center;\">喜怒哀乐我深锁</p>\r\n\r\n<p style=\"text-align: center;\">只因有你在天涯尽头等着我</p>\r\n\r\n<p style=\"text-align: center;\">人生风景在游走</p>\r\n\r\n<p style=\"text-align: center;\">每当孤独我回首</p>\r\n\r\n<p style=\"text-align: center;\">你的爱总在不远地方等着我</p>\r\n\r\n<p style=\"text-align: center;\">岁月如流在穿梭</p>\r\n\r\n<p style=\"text-align: center;\">喜怒哀乐我深锁</p>\r\n\r\n<p style=\"text-align: center;\">只因有你在天涯尽头等着我</p>\r\n\r\n<p style=\"text-align: center;\">人生风景在游走</p>\r\n\r\n<p style=\"text-align: center;\">每当孤独我回首</p>\r\n\r\n<p style=\"text-align: center;\">你的爱总在不远地方等着我</p>\r\n');
INSERT INTO `usernotice` VALUES ('23', '1', '0', '别问我是谁', '10/09/2017', '<p style=\"text-align: center;\">作曲 : 蔡议樟</p>\r\n\r\n<p style=\"text-align: center;\">作词 : 蔡议樟</p>\r\n\r\n<p style=\"text-align: center;\">从没说过爱着谁</p>\r\n\r\n<p style=\"text-align: center;\">为谁而憔悴</p>\r\n\r\n<p style=\"text-align: center;\">从来没有想过对不对</p>\r\n\r\n<p style=\"text-align: center;\">我的眼中装满疲惫</p>\r\n\r\n<p style=\"text-align: center;\">面对自己总觉得好累</p>\r\n\r\n<p style=\"text-align: center;\">我也需要人来陪</p>\r\n\r\n<p style=\"text-align: center;\">不让我心碎</p>\r\n\r\n<p style=\"text-align: center;\">让我爱到深处不后悔</p>\r\n\r\n<p style=\"text-align: center;\">其实我并不像他们说的</p>\r\n\r\n<p style=\"text-align: center;\">那样多刺难以安慰</p>\r\n\r\n<p style=\"text-align: center;\">爱人的心应该没有罪</p>\r\n\r\n<p style=\"text-align: center;\">为何在夜里却一再流泪</p>\r\n\r\n<p style=\"text-align: center;\">每天抱着寂寞入睡</p>\r\n\r\n<p style=\"text-align: center;\">生活过得没有滋味</p>\r\n\r\n<p style=\"text-align: center;\">别问我是谁</p>\r\n\r\n<p style=\"text-align: center;\">请与我相恋</p>\r\n\r\n<p style=\"text-align: center;\">我的真心没人能够体会</p>\r\n\r\n<p style=\"text-align: center;\">像我这样的人不多</p>\r\n\r\n<p style=\"text-align: center;\">为何还要让我难过</p>\r\n\r\n<p style=\"text-align: center;\">别问我是谁</p>\r\n\r\n<p style=\"text-align: center;\">请和我面对</p>\r\n\r\n<p style=\"text-align: center;\">看看我的眼角流下的泪</p>\r\n\r\n<p style=\"text-align: center;\">我和你并没有不同</p>\r\n\r\n<p style=\"text-align: center;\">但我的心更容易破碎</p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\">我也需要人来陪</p>\r\n\r\n<p style=\"text-align: center;\">不让我心碎</p>\r\n\r\n<p style=\"text-align: center;\">让我爱到深处不后悔</p>\r\n\r\n<p style=\"text-align: center;\">其实我并不像他们说的</p>\r\n\r\n<p style=\"text-align: center;\">那样多刺难以安慰</p>\r\n\r\n<p style=\"text-align: center;\">爱人的心应该没有罪</p>\r\n\r\n<p style=\"text-align: center;\">为何在夜里却一再流泪</p>\r\n\r\n<p style=\"text-align: center;\">每天抱着寂寞入睡</p>\r\n\r\n<p style=\"text-align: center;\">生活过得没有滋味</p>\r\n\r\n<p style=\"text-align: center;\">别问我是谁</p>\r\n\r\n<p style=\"text-align: center;\">请与我相恋</p>\r\n\r\n<p style=\"text-align: center;\">我的真心没人能够体会</p>\r\n\r\n<p style=\"text-align: center;\">像我这样的人不多</p>\r\n\r\n<p style=\"text-align: center;\">为何还要让我难过</p>\r\n\r\n<p style=\"text-align: center;\">别问我是谁</p>\r\n\r\n<p style=\"text-align: center;\">请和我面对</p>\r\n\r\n<p style=\"text-align: center;\">看看我的眼角流下的泪</p>\r\n\r\n<p style=\"text-align: center;\">我和你并没有不同</p>\r\n\r\n<p style=\"text-align: center;\">但我的心更容易破碎</p>\r\n\r\n<blockquote>\r\n<p style=\"text-align: center;\">别问我是谁</p>\r\n</blockquote>\r\n\r\n<p style=\"text-align: center;\">请与我相恋</p>\r\n\r\n<p style=\"text-align: center;\">我的真心没人能够体会</p>\r\n\r\n<p style=\"text-align: center;\">像我这样的人不多</p>\r\n\r\n<p style=\"text-align: center;\">为何还要让我难过</p>\r\n');
INSERT INTO `usernotice` VALUES ('26', '1', '0', '冲动的惩罚', '10/18/2017', '<p style=\"text-align: center;\">如果那天你不知道我喝了多少杯</p>\r\n\r\n<p style=\"text-align: center;\">你就不会明白你究竟有多美</p>\r\n\r\n<p style=\"text-align: center;\">我也不会相信 第一次看见你</p>\r\n\r\n<p style=\"text-align: center;\">就爱你爱得那么干脆</p>\r\n\r\n<p style=\"text-align: center;\">可是我相信我心中的感觉</p>\r\n\r\n<p style=\"text-align: center;\">它来得那么快 来得那么直接</p>\r\n\r\n<p style=\"text-align: center;\">就算我心狂野 无法将火熄灭</p>\r\n\r\n<p style=\"text-align: center;\">我依然相信是老天让你我相约</p>\r\n\r\n<p style=\"text-align: center;\">如果说没有闻到残留手中你的香水</p>\r\n\r\n<p style=\"text-align: center;\">我绝对不会辗转反侧难以入睡</p>\r\n\r\n<p style=\"text-align: center;\">就想着你的美 闻着你的香味</p>\r\n\r\n<p style=\"text-align: center;\">在冰与火的情欲中挣扎徘徊</p>\r\n\r\n<p style=\"text-align: center;\">如果说不是老天让缘份把我捉弄</p>\r\n\r\n<p style=\"text-align: center;\">想到你我就不会那么心痛</p>\r\n\r\n<p style=\"text-align: center;\">就把你忘记吧 应该把你忘了</p>\r\n\r\n<p style=\"text-align: center;\">这是对冲动最好的惩罚</p>\r\n\r\n<p style=\"text-align: center;\">直到你转身离去那一刻起 逐渐地清醒</p>\r\n\r\n<p style=\"text-align: center;\">才知道把我世界强加给你 还需要勇气</p>\r\n\r\n<p style=\"text-align: center;\">在你的内心里 是怎样对待感情</p>\r\n\r\n<p style=\"text-align: center;\">直到现在你都没有对我提起</p>\r\n\r\n<p style=\"text-align: center;\">我自说自话 简单的想法</p>\r\n\r\n<p style=\"text-align: center;\">在你看来这根本就是一个笑话</p>\r\n\r\n<p style=\"text-align: center;\">所以我伤悲 尽管手中还残留着你的香味</p>\r\n\r\n<p style=\"text-align: center;\">如果那天你不知道我喝了多少杯</p>\r\n\r\n<p style=\"text-align: center;\">你就不会明白你究竟有多美</p>\r\n\r\n<p style=\"text-align: center;\">我也不会相信 第一次看见你</p>\r\n\r\n<p style=\"text-align: center;\">就爱你爱得那么干脆</p>\r\n\r\n<p style=\"text-align: center;\">可是我相信我心中的感觉</p>\r\n\r\n<p style=\"text-align: center;\">它来得那么快 来得那么直接</p>\r\n\r\n<p style=\"text-align: center;\">就算我心狂野 无法将火熄灭</p>\r\n\r\n<p style=\"text-align: center;\">我依然相信是老天让你我相约</p>\r\n\r\n<p style=\"text-align: center;\">如果说没有闻到残留手中你的香水</p>\r\n\r\n<p style=\"text-align: center;\">我绝对不会辗转反侧难以入睡</p>\r\n\r\n<p style=\"text-align: center;\">就想着你的美 闻着你的香味</p>\r\n\r\n<p style=\"text-align: center;\">在冰与火的情欲中挣扎徘徊</p>\r\n\r\n<p style=\"text-align: center;\">如果说不是老天让缘份把我捉弄</p>\r\n\r\n<p style=\"text-align: center;\">想到你我就不会那么心痛</p>\r\n\r\n<p style=\"text-align: center;\">就把你忘记吧 应该把你忘了</p>\r\n\r\n<p style=\"text-align: center;\">这是对冲动最好的惩罚</p>\r\n\r\n<p style=\"text-align: center;\">这是对冲动最好的惩罚</p>\r\n\r\n<p style=\"text-align: center;\">Ha Ha</p>\r\n\r\n<p style=\"text-align: center;\">如果那天你不知道我喝了多少杯</p>\r\n\r\n<p style=\"text-align: center;\">你就不会明白你究竟有多美</p>\r\n\r\n<p style=\"text-align: center;\">我也不会相信 第一次看见你</p>\r\n\r\n<p style=\"text-align: center;\">就爱你爱得那么干脆</p>\r\n\r\n<p style=\"text-align: center;\">可是我相信我心中的感觉</p>\r\n\r\n<p style=\"text-align: center;\">它来得那么快 来得那么直接</p>\r\n\r\n<p style=\"text-align: center;\">就算我心狂野 无法将火熄灭</p>\r\n\r\n<p style=\"text-align: center;\">我依然相信是老天让你我相约</p>\r\n\r\n<p style=\"text-align: center;\">如果说没有闻到残留手中你的香水</p>\r\n\r\n<p style=\"text-align: center;\">我绝对不会辗转反侧难以入睡</p>\r\n\r\n<p style=\"text-align: center;\">就想着你的美</p>\r\n');
INSERT INTO `usernotice` VALUES ('30', '1', '0', '最远的你是我最近的爱', '10/25/2017', '<p style=\"text-align: center;\"><span style=\"color:#800000\"><strong>夜已沉默心事向谁说</strong></span></p>\r\n\r\n<p style=\"text-align: center;\">不肯回头所有的爱都错过</p>\r\n\r\n<p style=\"text-align: center;\">别笑我懦弱我始终不能猜透</p>\r\n\r\n<p style=\"text-align: center;\">为何人生淡漠</p>\r\n\r\n<p style=\"text-align: center;\">风雨之后无所谓拥有</p>\r\n\r\n<p style=\"text-align: center;\">萍水相逢你却给我那么多</p>\r\n');
INSERT INTO `usernotice` VALUES ('31', '4', '0', '最远的你是我最近的爱', '10/25/2017', '<p style=\"text-align: center;\"><span style=\"color:#800000\"><strong>夜已沉默心事向谁说</strong></span></p>\r\n\r\n<p style=\"text-align: center;\">不肯回头所有的爱都错过</p>\r\n\r\n<p style=\"text-align: center;\">别笑我懦弱我始终不能猜透</p>\r\n\r\n<p style=\"text-align: center;\">为何人生淡漠</p>\r\n\r\n<p style=\"text-align: center;\">风雨之后无所谓拥有</p>\r\n\r\n<p style=\"text-align: center;\">萍水相逢你却给我那么多</p>\r\n');
INSERT INTO `usernotice` VALUES ('33', '1', '0', '若没有不可舍弃的记忆就很无趣', '10/12/2017', '<p>そんなの検讨もつかない</p>\r\n\r\n<p>那样还有必要回顾么</p>\r\n\r\n<p>譲れない思いがなけりゃつまんない</p>\r\n\r\n<p>若没有不可舍弃的记忆就很无趣</p>\r\n\r\n<p>意味がない</p>\r\n\r\n<p>且没有意义</p>\r\n\r\n<p>そんなんじゃない</p>\r\n\r\n<p>不是这样的么?</p>\r\n');
INSERT INTO `usernotice` VALUES ('34', '4', '1', '若没有不可舍弃的记忆就很无趣', '10/12/2017', '<p>そんなの検讨もつかない</p>\r\n\r\n<p>那样还有必要回顾么</p>\r\n\r\n<p>譲れない思いがなけりゃつまんない</p>\r\n\r\n<p>若没有不可舍弃的记忆就很无趣</p>\r\n\r\n<p>意味がない</p>\r\n\r\n<p>且没有意义</p>\r\n\r\n<p>そんなんじゃない</p>\r\n\r\n<p>不是这样的么?</p>\r\n');
INSERT INTO `usernotice` VALUES ('35', '9', '0', '若没有不可舍弃的记忆就很无趣', '10/12/2017', '<p>そんなの検讨もつかない</p>\r\n\r\n<p>那样还有必要回顾么</p>\r\n\r\n<p>譲れない思いがなけりゃつまんない</p>\r\n\r\n<p>若没有不可舍弃的记忆就很无趣</p>\r\n\r\n<p>意味がない</p>\r\n\r\n<p>且没有意义</p>\r\n\r\n<p>そんなんじゃない</p>\r\n\r\n<p>不是这样的么?</p>\r\n');
INSERT INTO `usernotice` VALUES ('36', '9', '0', '我的一个道姑朋友', '10/18/2017', '<p style=\"text-align: center;\">作曲 : タイナカ彩智《一番星》</p>\r\n\r\n<p style=\"text-align: center;\">作词 : 陆菱纱</p>\r\n\r\n<p style=\"text-align: center;\">而你撑伞拥我入怀中，</p>\r\n\r\n<p style=\"text-align: center;\">一字一句誓言多慎重。</p>\r\n\r\n<p style=\"text-align: center;\">你眼中有柔情千种，</p>\r\n\r\n<p style=\"text-align: center;\">如脉脉春风，冰雪也消融。</p>\r\n\r\n<p style=\"text-align: center;\">原唱：LON</p>\r\n\r\n<p style=\"text-align: center;\">后期：圣雨轻纱</p>\r\n\r\n<p style=\"text-align: center;\">那年长街春意正浓，</p>\r\n\r\n<p style=\"text-align: center;\">策马同游，烟雨如梦。</p>\r\n\r\n<p style=\"text-align: center;\">檐下躲雨，</p>\r\n\r\n<p style=\"text-align: center;\">望进一双，深邃眼瞳，</p>\r\n\r\n<p style=\"text-align: center;\">宛如华山夹着细雪的微风。</p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\">雨丝微凉，</p>\r\n\r\n<p style=\"text-align: center;\">风吹过暗香朦胧。</p>\r\n\r\n<p style=\"text-align: center;\">一时心头悸动，似你温柔剑锋，</p>\r\n\r\n<p style=\"text-align: center;\">过处翩若惊鸿。</p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\">是否情字写来都空洞，</p>\r\n\r\n<p style=\"text-align: center;\">一笔一画斟酌着奉送，</p>\r\n\r\n<p style=\"text-align: center;\">甘愿卑微换个笑容，</p>\r\n\r\n<p style=\"text-align: center;\">或沦为平庸。</p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\">而你撑伞拥我入怀中，</p>\r\n\r\n<p style=\"text-align: center;\">一字一句誓言多慎重。</p>\r\n\r\n<p style=\"text-align: center;\">你眼中有柔情千种，</p>\r\n\r\n<p style=\"text-align: center;\">如脉脉春风，冰雪也消融。</p>\r\n');
INSERT INTO `usernotice` VALUES ('37', '9', '1', 'You Are Not Alone', '10/18/2017', '<p style=\"text-align: center;\">In my heart.....For I am here with you</p>\r\n\r\n<p style=\"text-align: center;\">在我心里 我和你在一起</p>\r\n\r\n<p style=\"text-align: center;\">Heart.....Though we&#39;re far apart</p>\r\n\r\n<p style=\"text-align: center;\">心里。尽快我们分开</p>\r\n\r\n<p style=\"text-align: center;\">Heart.....You&#39;re always in my heart</p>\r\n\r\n<p style=\"text-align: center;\">心里。你一直在我心里</p>\r\n\r\n<p style=\"text-align: center;\">For you are not alone</p>\r\n\r\n<p style=\"text-align: center;\">你不会孤单</p>\r\n\r\n<p style=\"text-align: center;\">Not alone</p>\r\n\r\n<p style=\"text-align: center;\">并不孤单</p>\r\n');
INSERT INTO `usernotice` VALUES ('38', '1', '0', '越难越爱', '12/10/2017', '<p>世界上哪里去找热望热似火 不褪落</p>\r\n\r\n<p>我对你心跳的感觉 高低跌荡</p>\r\n\r\n<p>最困惑那半秒钟念在有你的</p>\r\n\r\n<p>宽广的肩膊</p>\r\n\r\n<p>有勇气踏前觅幸福 从无回望</p>\r\n\r\n<p>再计算也没一种方法</p>\r\n\r\n<p>定论什么 讲对或</p>\r\n');
INSERT INTO `usernotice` VALUES ('39', '4', '1', '越难越爱', '12/10/2017', '<p>软弱会再有气概 跟处境比赛</p>\r\n\r\n<p>在途上就算有些感慨</p>\r\n\r\n<p>让我 学会抱紧撑到未来</p>\r\n\r\n<p>别让手放开</p>\r\n');
