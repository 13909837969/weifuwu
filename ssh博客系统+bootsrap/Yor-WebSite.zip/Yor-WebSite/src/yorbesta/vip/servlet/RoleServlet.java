package yorbesta.vip.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import yorbesta.vip.bean.Ico;
import yorbesta.vip.bean.Menu;
import yorbesta.vip.bean.Role;
import yorbesta.vip.bean.User;
import yorbesta.vip.service.BaseService;
import yorbesta.vip.service.IcoService;
import yorbesta.vip.service.MenuService;
import yorbesta.vip.service.RoleService;
import yorbesta.vip.service.UserService;
import yorbesta.vip.serviceImpl.UserServiceImpl;
import yorbesta.vip.utils.InitAdminPage;
import yorbesta.vip.utils.TokenProccessor;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(value = "/RoleServlet")
public class RoleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ApplicationContext applicationContext;
	private RoleService roleServiceImpl;
	private final Gson gson = new GsonBuilder().disableHtmlEscaping().create();
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		applicationContext = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
		roleServiceImpl = (RoleService) applicationContext.getBean("RoleServiceImpl");
	}

	protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
        
		if("list".equals(request.getParameter("role"))){
		    List<Role>  roleList =  roleServiceImpl.findAll("Role");
		    request.getSession().setAttribute("roleList", roleList);
			
	      }
		
		if("add".equals(request.getParameter("role"))){
			Role role=new Role();
			role.setRoleName(request.getParameter("roleName"));
			role.setRoleDesc(request.getParameter("roleDesc"));
			List<Integer> roleMenus =ToInts(request.getParameter("roleMenus"));
			role.setRoleMenus(roleMenus);
			roleServiceImpl.save(role);
	      }
		if("delete".equals(request.getParameter("role"))){
			 roleServiceImpl.deleteById(Integer.parseInt(request.getParameter("roleId")));
			
	     }
		if("update".equals(request.getParameter("role"))){
			 Role role= roleServiceImpl.findById(Integer.parseInt(request.getParameter("roleId")));
			 role.setRoleName(request.getParameter("roleName"));
			 role.setRoleDesc(request.getParameter("roleDesc"));
			 List<Integer> roleMenus =ToInts(request.getParameter("roleMenus"));
			 role.setRoleMenus(roleMenus);
			 roleServiceImpl.update(role);
	     }
		 List<Role>  roleList =  roleServiceImpl.findAll("Role");
		 request.getSession().setAttribute("roleList", roleList);
		 response.sendRedirect("manager/roleview.jsp");
		
		
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	  
	  
	public static  List<Integer> ToInts(String abc){  
		  
		 String[] arr=abc.split(",");
		 Integer[] result = new Integer[arr.length];  
		 
		 for (int i = 0; i <arr.length; i++) {  
			 String str = arr[i];  
			 result[i] = Integer.valueOf(str);
			 }   
		 return java.util.Arrays.asList(result);  
		}  
	  


}
