package yorbesta.vip.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import yorbesta.vip.bean.Menu;
import yorbesta.vip.bean.User;
import yorbesta.vip.service.BaseService;
import yorbesta.vip.service.MenuService;
import yorbesta.vip.service.UserService;
import yorbesta.vip.serviceImpl.UserServiceImpl;
import yorbesta.vip.utils.InitAdminPage;
import yorbesta.vip.utils.TokenProccessor;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(value = "/InitServlet")
public class InitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ApplicationContext applicationContext;
	private User user;
	private UserService userServiceImpl;
	private MenuService menuServiceImpl;
	private final Gson gson = new GsonBuilder().disableHtmlEscaping().create();
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		applicationContext = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
        user=(User) applicationContext.getBean("User");
		userServiceImpl = (UserService) applicationContext.getBean("UserServiceImpl");
		
		
	}

	protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
		 //初始化页面
		 // 首先加载菜单 团队状态  消息 邮件  最好在ININT中实现
		 InitAdminPage initAdminPage= userServiceImpl.initAdminPage(user);
		 request.getSession().setAttribute("initAdminPage", initAdminPage);
		 
		 
						
		 }

	

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	  
	  
	  
	public void setUser(User user) {
		this.user = user;
	}

	public void setUserServiceImpl(UserService userServiceImpl) {
		this.userServiceImpl = userServiceImpl;
	}


}
