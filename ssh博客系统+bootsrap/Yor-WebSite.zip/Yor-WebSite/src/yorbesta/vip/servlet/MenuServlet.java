package yorbesta.vip.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import yorbesta.vip.bean.Ico;
import yorbesta.vip.bean.Menu;
import yorbesta.vip.bean.User;
import yorbesta.vip.service.BaseService;
import yorbesta.vip.service.IcoService;
import yorbesta.vip.service.MenuService;
import yorbesta.vip.service.UserService;
import yorbesta.vip.serviceImpl.UserServiceImpl;
import yorbesta.vip.utils.InitAdminPage;
import yorbesta.vip.utils.TokenProccessor;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(value = "/MenuServlet")
public class MenuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ApplicationContext applicationContext;
	private MenuService menuServiceImpl;
	private IcoService icoServiceImpl;
	private final Gson gson = new GsonBuilder().disableHtmlEscaping().create();
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		applicationContext = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
		menuServiceImpl = (MenuService) applicationContext.getBean("MenuServiceImpl");
		icoServiceImpl = (IcoService) applicationContext.getBean("IcoServiceImpl");
	}

	protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
	
		
		if("ajax".equals(request.getParameter("menu"))){
			List<Menu>  menuList = menuServiceImpl.findAll("Menu");
			for(int i = 0 ; i < menuList.size() ; i++) {
			      if(menuList.get(i).getChildMenus()!=null){
			    	  menuList.get(i).getChildMenus().clear();
			      }
			} 
			 response.getWriter().print(gson.toJson(menuList));
	   }else{
		  
		   if("list".equals(request.getParameter("menu"))){
			    List<Ico>  icoList =  icoServiceImpl.findAll("Ico");
			    request.getSession().setAttribute("icoList", icoList);
		      }
			
			if("delete".equals(request.getParameter("menu"))){
				 menuServiceImpl.deleteById(Integer.parseInt(request.getParameter("menuId")));
		     }
			
			if("add".equals(request.getParameter("menu"))){
				Menu menu=new Menu();
				menu.setMenuName(request.getParameter("menuName"));
				menu.setMenuFather(Integer.parseInt(request.getParameter("menuFather")));
			    menu.setMenuUrl(request.getParameter("menuUrl"));
			    menu.setMenuPic(request.getParameter("menuPic"));
			    if("".equals(request.getParameter("menuOrder"))){
			    	menu.setMenuOrder(0);
			    }else{
			    	menu.setMenuOrder(Integer.valueOf(request.getParameter("menuOrder")));
			    }
			    menu.setChildMenus(new ArrayList<Menu>());
			    menuServiceImpl.save(menu);
			    //查看父菜单： 父菜单的父菜单为0，父菜单是一级菜单，本菜单是二级菜单
			    Menu fmenu=(Menu) menuServiceImpl.findById(Integer.parseInt(request.getParameter("menuFather")));
			    //如果不是一级菜单
			     if(fmenu.getMenuId()!=1){
			    	  fmenu.getChildMenus().add(menu);
					  menuServiceImpl.update(fmenu);
			     }       
			}
			
			if("update".equals(request.getParameter("menu"))){
				Menu menu= menuServiceImpl.findById(Integer.parseInt(request.getParameter("menuId")));
				menu.setMenuName(request.getParameter("menuName"));
			    menu.setMenuUrl(request.getParameter("menuUrl"));
			    menu.setMenuPic(request.getParameter("menuPic"));
			    if("".equals(request.getParameter("menuOrder"))){
			    	menu.setMenuOrder(0);
			    }else{
			    	menu.setMenuOrder(Integer.valueOf(request.getParameter("menuOrder")));
			    }
			    
			    menuServiceImpl.update(menu);
			}
			List<Menu>   menuList =  menuServiceImpl.findAll("Menu");
		    request.getSession().setAttribute("userMenuList", menuList);
			response.sendRedirect("manager/menuview.jsp");
	  }
		
		
		
		
		
		
		
		
		
		
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	  
	  
	  
	  


}
