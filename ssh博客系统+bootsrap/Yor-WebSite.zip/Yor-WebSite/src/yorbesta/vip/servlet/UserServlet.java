package yorbesta.vip.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import yorbesta.vip.bean.Ico;
import yorbesta.vip.bean.Menu;
import yorbesta.vip.bean.Role;
import yorbesta.vip.bean.User;
import yorbesta.vip.service.BaseService;
import yorbesta.vip.service.IcoService;
import yorbesta.vip.service.MenuService;
import yorbesta.vip.service.RoleService;
import yorbesta.vip.service.UserService;
import yorbesta.vip.serviceImpl.UserServiceImpl;
import yorbesta.vip.utils.InitAdminPage;
import yorbesta.vip.utils.TokenProccessor;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(value = "/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ApplicationContext applicationContext;
	private UserService userServiceImpl;
	private RoleService roleServiceImpl;
	private final Gson gson = new GsonBuilder().disableHtmlEscaping().create();
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		applicationContext = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
		userServiceImpl = (UserService) applicationContext.getBean("UserServiceImpl");
		roleServiceImpl = (RoleService) applicationContext.getBean("RoleServiceImpl");
	}

	protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
        
		
		
		if("list".equals(request.getParameter("user"))){
			 List<Role>  roleList =  roleServiceImpl.findAll("Role");
			 request.getSession().setAttribute("roleList", roleList);
	      }
		if("update".equals(request.getParameter("user"))){
			 User user= userServiceImpl.findById(Integer.parseInt(request.getParameter("userId")));
			 user.setUserName(request.getParameter("userName"));
			 user.setUserNickName(request.getParameter("userNickName"));
			 user.setUserEmail(request.getParameter("userEmail"));
			 user.setUserPassWord(request.getParameter("userPassWord"));
			 user.setUserPic(request.getParameter("userPic"));
			 
			 userServiceImpl.update(user);
			   if(request.getParameter("userRole")!=null){
				   int roleId=Integer.parseInt(request.getParameter("userRole"));
					 userServiceImpl.updateRoleId(roleId,user.getUserId());
			   }
			
			 
	     }
		
		if("delete".equals(request.getParameter("user"))){
			 User user= userServiceImpl.findById(Integer.parseInt(request.getParameter("userId")));
			 userServiceImpl.delete(user);
			 userServiceImpl.deleteRoleId(user.getUserId());
	     }
		 
		
		 List<User>  userList =  userServiceImpl.findAll("User");
		 request.getSession().setAttribute("userList", userList);
	     if("index".equals(request.getParameter("toJsp"))){
	    	 User user= userServiceImpl.findById(Integer.parseInt(request.getParameter("userId")));
	    	    request.getSession().setAttribute("user", user);
	    	    response.sendRedirect("manager/admin_Index.jsp");
	     }else{
	    	    response.sendRedirect("manager/userview.jsp");
	     }
		
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	  
	  
	public static  List<Integer> ToInts(String abc){  
		  
		 String[] arr=abc.split(",");
		 Integer[] result = new Integer[arr.length];  
		 
		 for (int i = 0; i <arr.length; i++) {  
			 String str = arr[i];  
			 result[i] = Integer.valueOf(str);
			 }   
		 return java.util.Arrays.asList(result);  
		}  
	  


}
