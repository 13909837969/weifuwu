package yorbesta.vip.utils;

public class InitAdminPage {
	

}
