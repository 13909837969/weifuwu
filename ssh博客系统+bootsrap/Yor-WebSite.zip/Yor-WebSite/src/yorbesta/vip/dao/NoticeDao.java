package yorbesta.vip.dao;

import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.UserNotice;


public interface NoticeDao extends BaseDao<Notice> {

	Notice findById(int id);



}
