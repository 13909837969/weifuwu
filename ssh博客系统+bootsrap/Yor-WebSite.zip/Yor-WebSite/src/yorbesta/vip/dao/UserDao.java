package yorbesta.vip.dao;

import yorbesta.vip.bean.User;
import yorbesta.vip.utils.InitAdminPage;

public interface UserDao extends BaseDao<User> {
	public User findEmail(String email);
	public User LoginCheck(String email, String pass) ;
	public InitAdminPage initAdminPage(User user);
	public User findById(int id);
	public void updateRoleId(int roleId, Integer userId);
	public void deleteRoleId(Integer userId);
}
