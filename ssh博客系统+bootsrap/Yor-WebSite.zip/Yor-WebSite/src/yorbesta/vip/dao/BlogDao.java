package yorbesta.vip.dao;

import yorbesta.vip.bean.Blog;
import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.UserNotice;


public interface BlogDao extends BaseDao<Blog> {

	Blog findById(int id);



}
