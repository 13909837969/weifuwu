package yorbesta.vip.dao;

import yorbesta.vip.bean.Files;
import yorbesta.vip.bean.User;
import yorbesta.vip.utils.InitAdminPage;

public interface FileDao extends BaseDao<Files> {

	Files deleteById(Integer integer);

	void deleteFile(String fileUrl, String fileUuuName);
}
