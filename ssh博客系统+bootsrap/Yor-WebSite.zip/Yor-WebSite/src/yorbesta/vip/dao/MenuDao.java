package yorbesta.vip.dao;

import java.util.List;

import yorbesta.vip.bean.Menu;

public interface MenuDao extends BaseDao<Menu> {

	List<Menu> findUseMenu(int roleid);

	Menu findById(int id);

	void deleteById(int id);
}
