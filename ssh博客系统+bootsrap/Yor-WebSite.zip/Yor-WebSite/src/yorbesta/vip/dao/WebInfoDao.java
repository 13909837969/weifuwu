package yorbesta.vip.dao;

import yorbesta.vip.bean.Blog;
import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.UserNotice;
import yorbesta.vip.bean.WebInfo;


public interface WebInfoDao extends BaseDao<WebInfo> {

	WebInfo findById(int id);



}
