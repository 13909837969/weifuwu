package yorbesta.vip.dao;

import yorbesta.vip.bean.Ico;
import yorbesta.vip.bean.Menu;

public interface IcoDao extends BaseDao<Ico>{

}
