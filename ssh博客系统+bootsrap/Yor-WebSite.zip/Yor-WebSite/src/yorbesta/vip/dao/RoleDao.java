package yorbesta.vip.dao;

import yorbesta.vip.bean.Role;

public interface RoleDao extends BaseDao<Role> {

	int findByUserId(Integer userId);

	void saveUserId(Integer userId);

	void deleteById(int id);
	Role findById(int id);
}
