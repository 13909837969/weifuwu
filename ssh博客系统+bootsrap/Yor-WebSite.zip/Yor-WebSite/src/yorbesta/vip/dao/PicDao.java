package yorbesta.vip.dao;

import yorbesta.vip.bean.Files;
import yorbesta.vip.bean.Pics;
import yorbesta.vip.bean.User;
import yorbesta.vip.utils.InitAdminPage;

public interface PicDao extends BaseDao<Pics> {

	Pics deleteById(Integer integer);

}
