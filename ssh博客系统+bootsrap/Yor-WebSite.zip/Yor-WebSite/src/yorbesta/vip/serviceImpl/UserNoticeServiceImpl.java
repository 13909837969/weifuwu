package yorbesta.vip.serviceImpl;


import java.util.List;

import yorbesta.vip.bean.Role;
import yorbesta.vip.bean.UserNotice;
import yorbesta.vip.dao.RoleDao;
import yorbesta.vip.dao.UserNoticeDao;
import yorbesta.vip.daoImpl.RoleDaoImpl;
import yorbesta.vip.daoImpl.UserNoticeDaoImpl;
import yorbesta.vip.service.RoleService;
import yorbesta.vip.service.UserNoticeService;

public class UserNoticeServiceImpl extends BaseServiceImpl<UserNotice> implements UserNoticeService {
	
	private UserNoticeDao userNoticeDaoImpl = null;
	public void setUserNoticeDaoImpl(UserNoticeDaoImpl userNoticeDaoImpl) {
		 super.setBaseDaoImpl(userNoticeDaoImpl);   
		 this.userNoticeDaoImpl = userNoticeDaoImpl;
	}
	@Override
	public List<UserNotice> findAllByUserId(int id) {
		// TODO Auto-generated method stub
		return userNoticeDaoImpl.findAllByUserId(id);
	}
	@Override
	public UserNotice findById(int id) {
		// TODO Auto-generated method stub
		return userNoticeDaoImpl.findById(id);
	}
	@Override
	public List<UserNotice> findNoReadById(Integer userId) {
		// TODO Auto-generated method stub
		return userNoticeDaoImpl.findNoReadById(userId);
	}







}
