package yorbesta.vip.serviceImpl;

import yorbesta.vip.bean.Blog;
import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.UserNotice;
import yorbesta.vip.dao.BlogDao;
import yorbesta.vip.dao.NoticeDao;
import yorbesta.vip.daoImpl.BlogDaoImpl;
import yorbesta.vip.daoImpl.NoticeDaoImpl;
import yorbesta.vip.service.BlogService;
import yorbesta.vip.service.NoticeService;



public class BlogServiceImpl extends BaseServiceImpl<Blog> implements BlogService {
	
	private BlogDao blogDaoImpl = null;
	public void setBlogDaoImpl(BlogDaoImpl blogDaoImpl) {
		 super.setBaseDaoImpl(blogDaoImpl);   
		 this.blogDaoImpl = blogDaoImpl;
	}
	@Override
	public Blog findById(int id) {
		// TODO Auto-generated method stub
		return blogDaoImpl.findById(id);
	}







}
