package yorbesta.vip.serviceImpl;


import yorbesta.vip.bean.Role;
import yorbesta.vip.dao.RoleDao;
import yorbesta.vip.daoImpl.RoleDaoImpl;
import yorbesta.vip.service.RoleService;

public class RoleServiceImpl extends BaseServiceImpl<Role> implements RoleService {
	
	private RoleDao roleDaoImpl = null;
	public void setRoleDaoImpl(RoleDaoImpl roleDaoImpl) {
		 super.setBaseDaoImpl(roleDaoImpl);   
		 this.roleDaoImpl = roleDaoImpl;
	}
	@Override
	public int findByUserId(Integer userId) {
		// TODO Auto-generated method stub
		return roleDaoImpl.findByUserId(userId);
	}
	@Override
	public void saveUserId(Integer userId) {
		// TODO Auto-generated method stub
		roleDaoImpl.saveUserId(userId);
	}
	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		roleDaoImpl.deleteById(id);
	}
	@Override
	public Role findById(int id) {
		// TODO Auto-generated method stub
		return roleDaoImpl.findById(id);
	}







}
