package yorbesta.vip.serviceImpl;


import java.util.List;

import yorbesta.vip.bean.Ico;
import yorbesta.vip.bean.Menu;
import yorbesta.vip.dao.IcoDao;
import yorbesta.vip.dao.MenuDao;
import yorbesta.vip.daoImpl.IcoDaoImpl;
import yorbesta.vip.daoImpl.MenuDaoImpl;
import yorbesta.vip.service.IcoService;
import yorbesta.vip.service.MenuService;

public class IcoServiceImpl extends BaseServiceImpl<Ico> implements IcoService {
	
	private IcoDao icoDaoImpl = null;
	public void setIcoDaoImpl(IcoDaoImpl icoDaoImpl) {
		 super.setBaseDaoImpl(icoDaoImpl);   
		 this.icoDaoImpl = icoDaoImpl;
	}







}
