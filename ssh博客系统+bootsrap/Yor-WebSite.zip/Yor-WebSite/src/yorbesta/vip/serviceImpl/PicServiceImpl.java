package yorbesta.vip.serviceImpl;


import yorbesta.vip.bean.Files;
import yorbesta.vip.bean.Pics;
import yorbesta.vip.dao.FileDao;
import yorbesta.vip.dao.PicDao;
import yorbesta.vip.daoImpl.FileDaoImpl;
import yorbesta.vip.daoImpl.PicDaoImpl;
import yorbesta.vip.service.FileService;
import yorbesta.vip.service.PicService;

public class PicServiceImpl extends BaseServiceImpl<Pics> implements PicService {
	
	private PicDao picDaoImpl = null;
	public void setPicDaoImpl(PicDaoImpl picDaoImpl) {
		  super.setBaseDaoImpl(picDaoImpl);   
		  this.picDaoImpl = picDaoImpl;
	}
	@Override
	public Pics findById(Integer integer) {
		// TODO Auto-generated method stub
		return picDaoImpl.deleteById(integer);
	}





}
