package yorbesta.vip.serviceImpl;

import yorbesta.vip.bean.Blog;
import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.UserNotice;
import yorbesta.vip.bean.WebInfo;
import yorbesta.vip.dao.BlogDao;
import yorbesta.vip.dao.NoticeDao;
import yorbesta.vip.dao.WebInfoDao;
import yorbesta.vip.daoImpl.BlogDaoImpl;
import yorbesta.vip.daoImpl.NoticeDaoImpl;
import yorbesta.vip.daoImpl.WebInfoDaoImpl;
import yorbesta.vip.service.BlogService;
import yorbesta.vip.service.NoticeService;
import yorbesta.vip.service.WebInfoService;



public class WebInfoServiceImpl extends BaseServiceImpl<WebInfo> implements WebInfoService {
	
	private WebInfoDao webInfoDaoImpl = null;
	public void setWebInfoDaoImpl(WebInfoDaoImpl webInfoDaoImpl) {
		 super.setBaseDaoImpl(webInfoDaoImpl);   
		 this.webInfoDaoImpl = webInfoDaoImpl;
	}
	@Override
	public WebInfo findById(int id) {
		// TODO Auto-generated method stub
		return webInfoDaoImpl.findById(id);
	}







}
