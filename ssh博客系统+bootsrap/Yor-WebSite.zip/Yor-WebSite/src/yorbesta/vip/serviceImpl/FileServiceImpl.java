package yorbesta.vip.serviceImpl;


import yorbesta.vip.bean.Files;
import yorbesta.vip.dao.FileDao;
import yorbesta.vip.daoImpl.FileDaoImpl;
import yorbesta.vip.service.FileService;

public class FileServiceImpl extends BaseServiceImpl<Files> implements FileService {
	
	private FileDao fileDaoImpl = null;
	public void setFileDaoImpl(FileDaoImpl fileDaoImpl) {
		  super.setBaseDaoImpl(fileDaoImpl);   
		  this.fileDaoImpl = fileDaoImpl;
	}
	@Override
	public Files findById(Integer integer) {
		// TODO Auto-generated method stub
		return fileDaoImpl.deleteById(integer);
	}
	@Override
	public void deleteFile(String fileUrl, String fileUuuName) {
		// TODO Auto-generated method stub
		fileDaoImpl.deleteFile(fileUrl,fileUuuName);
	}





}
