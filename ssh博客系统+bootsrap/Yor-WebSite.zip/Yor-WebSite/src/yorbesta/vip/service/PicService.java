package yorbesta.vip.service;

import yorbesta.vip.bean.Files;
import yorbesta.vip.bean.Pics;

public interface  PicService extends  BaseService<Pics> {

	Pics findById(Integer integer);

}
