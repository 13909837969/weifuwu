package yorbesta.vip.service;

import yorbesta.vip.bean.Ico;
import yorbesta.vip.bean.Menu;

public interface IcoService extends  BaseService<Ico> {

}
