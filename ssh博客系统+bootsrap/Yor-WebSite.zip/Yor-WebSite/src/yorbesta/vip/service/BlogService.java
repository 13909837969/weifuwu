package yorbesta.vip.service;

import yorbesta.vip.bean.Blog;
import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.UserNotice;
import yorbesta.vip.utils.InitAdminPage;

public interface  BlogService extends  BaseService<Blog> {

	Blog findById(int parseInt);


}
