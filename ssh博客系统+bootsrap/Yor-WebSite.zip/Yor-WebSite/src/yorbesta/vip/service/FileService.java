package yorbesta.vip.service;

import yorbesta.vip.bean.Files;

public interface  FileService extends  BaseService<Files> {

	Files findById(Integer integer);

	void deleteFile(String fileUrl, String fileUuuName);
}
