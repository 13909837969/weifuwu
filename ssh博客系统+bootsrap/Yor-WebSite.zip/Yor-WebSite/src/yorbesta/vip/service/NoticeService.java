package yorbesta.vip.service;

import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.UserNotice;
import yorbesta.vip.utils.InitAdminPage;

public interface  NoticeService extends  BaseService<Notice> {

	Notice findById(int parseInt);


}
