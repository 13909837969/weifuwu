package yorbesta.vip.service;

import java.util.List;

import yorbesta.vip.bean.Role;


public interface  RoleService extends  BaseService<Role> {

	int findByUserId(Integer userId);

	void saveUserId(Integer userId);

	void deleteById(int parseInt);

	Role findById(int id);


}
