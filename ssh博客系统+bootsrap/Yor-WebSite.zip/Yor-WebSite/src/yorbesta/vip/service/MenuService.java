package yorbesta.vip.service;

import java.util.List;

import yorbesta.vip.bean.Menu;

public interface  MenuService extends  BaseService<Menu> {

	List<Menu> findUseMenu(int roleid);

	Menu findById(int id);

	void deleteById(int parseInt);




}
