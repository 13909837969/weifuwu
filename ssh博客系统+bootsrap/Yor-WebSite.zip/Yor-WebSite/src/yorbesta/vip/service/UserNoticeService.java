package yorbesta.vip.service;

import java.util.List;

import yorbesta.vip.bean.UserNotice;



public interface  UserNoticeService extends  BaseService<UserNotice> {

	java.util.List<UserNotice> findAllByUserId(int parseInt);

	UserNotice findById(int parseInt);

	List<UserNotice> findNoReadById(Integer userId);



}
