package yorbesta.vip.daoImpl;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.User;
import yorbesta.vip.bean.UserNotice;
import yorbesta.vip.dao.NoticeDao;


public class NoticeDaoImpl extends BaseDaoImpl<Notice> implements NoticeDao{

	@Override
	public Notice findById(int id) {
		// TODO Auto-generated method stub
		List<Notice> noticeList=getHibernateTemplate().find("from yorbesta.vip.bean.Notice where noticeId="+id);
		 if(noticeList.size()>0){
			 return  noticeList.get(0);
		 }else{
			 return  new Notice();
		 }
		
	}



	


	
}
