package yorbesta.vip.daoImpl;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import yorbesta.vip.bean.Role;
import yorbesta.vip.bean.User;
import yorbesta.vip.dao.UserDao;
import yorbesta.vip.utils.InitAdminPage;

public class UserDaoImpl extends BaseDaoImpl<User> implements UserDao{
	
	@Override
	public User findEmail(String email) {
		// TODO Auto-generated method stub
	      
		List<User> userlist=
		getHibernateTemplate().find("from yorbesta.vip.bean.User where userEmail='"+email+"'");
		if(userlist.size()>=1){
			return userlist.get(0);
		}else{
			return new User();
		}
		
	}

	public User LoginCheck(String email, String pass) {
		// TODO Auto-generated method stub
		List<User> userlist=
		getHibernateTemplate().find("from yorbesta.vip.bean.User where userEmail='"+email+"'" +"and userPassWord='" +pass+"'" );
	    if(userlist.size()>=1){
	    	return userlist.get(0);
	    }else{
	    	return new User();
	    }
	}


	@Override
	public InitAdminPage initAdminPage(User user) {
		// TODO Auto-generated method stub
		InitAdminPage initAdminPage=new InitAdminPage();
		return initAdminPage;
	}

	@Override
	public User findById(int id) {
		// TODO Auto-generated method stub
		List<User> userList=getHibernateTemplate().find("from yorbesta.vip.bean.User where userId="+id);
		return  userList.get(0);
	}

	@Override
	public void updateRoleId(int roleId, Integer userId) {
		// TODO Auto-generated method stub
		 Session session = getHibernateTemplate().getSessionFactory().getCurrentSession() ;
		 Query query = session.createSQLQuery("update  role_users set roleId ="+roleId+" where userid="+userId);
		 query.executeUpdate();
	}

	@Override
	public void deleteRoleId(Integer userId) {
		// TODO Auto-generated method stub
		Session session = getHibernateTemplate().getSessionFactory().getCurrentSession() ;
		 Query query = session.createSQLQuery("delete  from  role_users  where userid="+userId);
		 query.executeUpdate();
	}


	
}
