package yorbesta.vip.daoImpl;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import yorbesta.vip.bean.Blog;
import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.User;
import yorbesta.vip.bean.UserNotice;
import yorbesta.vip.bean.WebInfo;
import yorbesta.vip.dao.BlogDao;
import yorbesta.vip.dao.NoticeDao;
import yorbesta.vip.dao.WebInfoDao;


public class WebInfoDaoImpl extends BaseDaoImpl<WebInfo> implements WebInfoDao{

	@Override
	public WebInfo findById(int id) {
		// TODO Auto-generated method stub
		List<WebInfo> WebInfoList=getHibernateTemplate().find("from yorbesta.vip.bean.WebInfo where WebInfoId="+id);
		 if(WebInfoList.size()>0){
			 return  WebInfoList.get(0);
		 }else{
			 return  new WebInfo();
		 }
		
	}



	


	
}
