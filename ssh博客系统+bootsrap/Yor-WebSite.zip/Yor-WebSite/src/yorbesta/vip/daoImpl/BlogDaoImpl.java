package yorbesta.vip.daoImpl;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import yorbesta.vip.bean.Blog;
import yorbesta.vip.bean.Notice;
import yorbesta.vip.bean.User;
import yorbesta.vip.bean.UserNotice;
import yorbesta.vip.dao.BlogDao;
import yorbesta.vip.dao.NoticeDao;


public class BlogDaoImpl extends BaseDaoImpl<Blog> implements BlogDao{

	@Override
	public Blog findById(int id) {
		// TODO Auto-generated method stub
		List<Blog> blogList=getHibernateTemplate().find("from yorbesta.vip.bean.Blog where blogId="+id);
		 if(blogList.size()>0){
			 return  blogList.get(0);
		 }else{
			 return  new Blog();
		 }
		
	}



	


	
}
