package yorbesta.vip.daoImpl;

import java.util.List;

import yorbesta.vip.bean.Ico;
import yorbesta.vip.bean.Menu;
import yorbesta.vip.dao.IcoDao;
import yorbesta.vip.dao.MenuDao;

public class IcoDaoImpl extends BaseDaoImpl<Ico> implements IcoDao{




}
