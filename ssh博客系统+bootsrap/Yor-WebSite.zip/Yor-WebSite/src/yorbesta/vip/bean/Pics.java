package yorbesta.vip.bean;

public class Pics {
private Integer picId;	
private String picSourceUrl;
private String picUrl;
private String picInfo1;
private String picInfo2;
private String picInfo3;
public Integer getPicId() {
	return picId;
}
public String getPicSourceUrl() {
	return picSourceUrl;
}
public String getPicUrl() {
	return picUrl;
}
public String getPicInfo1() {
	return picInfo1;
}
public String getPicInfo2() {
	return picInfo2;
}
public String getPicInfo3() {
	return picInfo3;
}
public void setPicId(Integer picId) {
	this.picId = picId;
}
public void setPicSourceUrl(String picSourceUrl) {
	this.picSourceUrl = picSourceUrl;
}
public void setPicUrl(String picUrl) {
	this.picUrl = picUrl;
}
public void setPicInfo1(String picInfo1) {
	this.picInfo1 = picInfo1;
}
public void setPicInfo2(String picInfo2) {
	this.picInfo2 = picInfo2;
}
public void setPicInfo3(String picInfo3) {
	this.picInfo3 = picInfo3;
}



}
