package yorbesta.vip.bean;

import java.util.List;

public class Ico {
private Integer icoId;	 //角色ID
private String  icoName;    //角色名称
public Integer getIcoId() {
	return icoId;
}
public void setIcoId(Integer icoId) {
	this.icoId = icoId;
}
public String getIcoName() {
	return icoName;
}
public void setIcoName(String icoName) {
	this.icoName = icoName;
}

}
