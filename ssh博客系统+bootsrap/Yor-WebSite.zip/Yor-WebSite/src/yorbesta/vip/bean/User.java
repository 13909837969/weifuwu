package yorbesta.vip.bean;

public class User {
private Integer userId;	
private String userName;
private String userNickName;
private String userPassWord;
private String userEmail;
private String userPic;
public Integer getUserId() {
	return userId;
}
public void setUserId(Integer userId) {
	this.userId = userId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserNickName() {
	return userNickName;
}
public void setUserNickName(String userNickName) {
	this.userNickName = userNickName;
}
public String getUserPassWord() {
	return userPassWord;
}
public void setUserPassWord(String userPassWord) {
	this.userPassWord = userPassWord;
}
public String getUserEmail() {
	return userEmail;
}
public void setUserEmail(String userEmail) {
	this.userEmail = userEmail;
}
@Override
public String toString() {
	return "User [userId=" + userId + ", userName=" + userName
			+ ", userNickName=" + userNickName + ", userPassWord="
			+ userPassWord + ", userEmail=" + userEmail 
			+  "]";
}
public String getUserPic() {
	return userPic;
}
public void setUserPic(String userPic) {
	this.userPic = userPic;
}


}
