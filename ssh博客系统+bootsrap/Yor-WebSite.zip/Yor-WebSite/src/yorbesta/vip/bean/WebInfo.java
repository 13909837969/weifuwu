package yorbesta.vip.bean;

import java.util.List;

public class WebInfo {
private Integer webInfoId;
private String  webTitle;	
public String getWebTitle() {
	return webTitle;
}
public void setWebTitle(String webTitle) {
	this.webTitle = webTitle;
}
private String  webSummary;	
private String  webIntroduction;
private String  brandTitle;
private String  brandSummary;
private String  brandIntroduction;
private String  brandBackPic;
private Integer blogId;
private String  aboutTitle;
private String  aboutSummary;
private String  aboutIntroduction;
private String  aboutInfo;
private String  aboutPic1;
private String  aboutPic2;
private String  aboutPic3;
public Integer getWebInfoId() {
	return webInfoId;
}
public String getWebSummary() {
	return webSummary;
}
public String getWebIntroduction() {
	return webIntroduction;
}
public String getBrandTitle() {
	return brandTitle;
}
public String getBrandSummary() {
	return brandSummary;
}
public String getBrandIntroduction() {
	return brandIntroduction;
}
public String getBrandBackPic() {
	return brandBackPic;
}
public Integer getBlogId() {
	return blogId;
}
public String getAboutTitle() {
	return aboutTitle;
}
public String getAboutSummary() {
	return aboutSummary;
}
public String getAboutIntroduction() {
	return aboutIntroduction;
}
public String getAboutInfo() {
	return aboutInfo;
}
public String getAboutPic1() {
	return aboutPic1;
}
public String getAboutPic2() {
	return aboutPic2;
}
public String getAboutPic3() {
	return aboutPic3;
}
public void setWebInfoId(Integer webInfoId) {
	this.webInfoId = webInfoId;
}
public void setWebSummary(String webSummary) {
	this.webSummary = webSummary;
}
public void setWebIntroduction(String webIntroduction) {
	this.webIntroduction = webIntroduction;
}
public void setBrandTitle(String brandTitle) {
	this.brandTitle = brandTitle;
}
public void setBrandSummary(String brandSummary) {
	this.brandSummary = brandSummary;
}
public void setBrandIntroduction(String brandIntroduction) {
	this.brandIntroduction = brandIntroduction;
}
public void setBrandBackPic(String brandBackPic) {
	this.brandBackPic = brandBackPic;
}
public void setBlogId(Integer blogId) {
	this.blogId = blogId;
}
public void setAboutTitle(String aboutTitle) {
	this.aboutTitle = aboutTitle;
}
public void setAboutSummary(String aboutSummary) {
	this.aboutSummary = aboutSummary;
}
public void setAboutIntroduction(String aboutIntroduction) {
	this.aboutIntroduction = aboutIntroduction;
}
public void setAboutInfo(String aboutInfo) {
	this.aboutInfo = aboutInfo;
}
public void setAboutPic1(String aboutPic1) {
	this.aboutPic1 = aboutPic1;
}
public void setAboutPic2(String aboutPic2) {
	this.aboutPic2 = aboutPic2;
}
public void setAboutPic3(String aboutPic3) {
	this.aboutPic3 = aboutPic3;
}



}
