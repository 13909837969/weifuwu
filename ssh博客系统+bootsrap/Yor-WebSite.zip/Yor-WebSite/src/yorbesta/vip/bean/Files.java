package yorbesta.vip.bean;

public class Files {
private Integer fileId;	
private String fileName;
private String fileUuuName;
private String filePath;
private String fileUrl;
private String fileType;
public Integer getFileId() {
	return fileId;
}
public void setFileId(Integer fileId) {
	this.fileId = fileId;
}
public String getFileName() {
	return fileName;
}
public void setFileName(String fileName) {
	this.fileName = fileName;
}
public String getFileUuuName() {
	return fileUuuName;
}
public void setFileUuuName(String fileUuuName) {
	this.fileUuuName = fileUuuName;
}
public String getFileUrl() {
	return fileUrl;
}
public void setFileUrl(String fileUrl) {
	this.fileUrl = fileUrl;
}
public String getFilePath() {
	return filePath;
}
public void setFilePath(String filePath) {
	this.filePath = filePath;
}
public String getFileType() {
	return fileType;
}
public void setFileType(String fileType) {
	this.fileType = fileType;
}


}
